function moveTrails(){
    for(var i in trails){
        trails[i].zmiana += 1;
        if(trails[i].zmiana > trails[i].dystans){
            trails[i].kierunek = (trails[i].kierunek+1)%2
            trails[i].zmiana = 0
        }
        if(trails[i].kierunek == 0){
            trails[i].ustawienie = (trails[i].ustawienie+2)%(trails[i].grafika.naturalWidth/9 + 8)
        }else{
            var minus = ((trails[i].grafika.naturalWidth/9 + 8) - (trails[i].ustawienie-2))%(trails[i].grafika.naturalWidth/9 + 8)
            trails[i].ustawienie = (trails[i].grafika.naturalWidth/9 + 8) - minus
        }
    }
}
        function animate(){
            var cT=document.getElementById("cTrails"),
                ctxT=cT.getContext("2d"),
                cS=document.getElementById("cScore"),
                ctxS=cS.getContext("2d"),
                cP=document.getElementById("cPlayer"),
                ctxP=cP.getContext("2d")
            ctxT.clearRect(
                0, 
                trails[0].pozycja*cT.height/210, 
                cT.width, 
                11*trails.length*cT.height/210
            )
            /*ctxT.rect(
                0, 
                trails[0].pozycja*cT.height/210, 
                cT.width, 
                11*trails.length*cT.height/210
            )
            ctxT.fill()*/
            //ctxS.clearRect(0, 0, cS.width, cS.height/10)
            ctxP.clearRect(0, 0, cP.width, cP.height)
            /*for(var i = 0; i < 3; i++){
                ctxS.rect(0, 0, cS.width ,cS.height*(38+(11*i))/210);
                ctxS.lineWidth = 1;//cT.width/320;
                ctxS.strokeStyle = "red"
                ctxS.stroke();
            }*/
            score++
            updateScore("score")
            ctxP.drawImage(
                player.grafiki[0],
                player.pozycja*cP.width/320,
                player.wysokosc*cP.height/210,
                player.grafiki[0].naturalWidth/9*cP.width/320,
                player.grafiki[0].naturalHeight/9*cP.height/210
            )
            if(player.skok == 0){
                ctxP.drawImage(
                    player.grafiki[1],
                    (player.pozycja + player.grafiki[0].naturalWidth/9 - 2)*cP.width/320,
                    player.wysokosc*cP.height/210,
                    player.grafiki[1].naturalWidth/9*cP.width/320,
                    player.grafiki[1].naturalHeight/9*cP.height/210
                )
            }else{
                ctxP.drawImage(
                    player.grafiki[Math.ceil(((player.skok%12) + 1)/6)],
                    (player.pozycja + player.grafiki[0].naturalWidth/9 - 2)*cP.width/320,
                    (player.wysokosc-player.grafiki[0].naturalHeight/9)*cP.height/210,
                    player.grafiki[1].naturalWidth/9*cP.width/320,
                    player.grafiki[1].naturalHeight/9*cP.height/210
                )
                if(player.skok > 0)
                    player.skok --
            }
            for(var i in trails){
                var next = 0
                do {
                    ctxT.drawImage(
                        trails[i].grafika,
                        (trails[i].ustawienie - trails[i].dlugosc - 24 + next)*cP.width/320,
                        (trails[i].pozycja - 0)*cT.height/210,
                        trails[i].grafika.naturalWidth/9*cT.width/320,
                        trails[i].grafika.naturalHeight/9*cT.height/210
                    )
                    next += trails[i].grafika.naturalWidth/9 + 8
                }
                while(next < 320 + 32 + trails[i].grafika.naturalWidth/9 - trails[i].ustawienie)
            }
            /*for(var i in trails) {
                var img = new Image();
                img.onload = (function (nr) {
                    ctx.drawImage(
                        trails[nr].grafika,
                        (trails[nr].ustawienie + 5)*cT.width/320,
                        (trails[nr].pozycja + 10)*cT.height/210,
                        (trails[nr].dlugosc - 8)*cT.width/320,
                        trails[nr].wysokosc*cT.height/210
                    )
                }(i))
            }*/
        }
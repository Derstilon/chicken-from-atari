function _Controls() {
    this.keycodes = [];
    this.pressed = [];
    for(var i in arguments){
        this.keycodes.push(arguments[i]);
        this.pressed[i] = false
    }
}
function makeControls() {
    controls = new _Controls(37, 38, 39, 13)
    window.onkeydown = function(event){
        for(var i in controls.keycodes){
            if(event.keyCode == controls.keycodes[i]){
                if(player.skok == 0 && controls.pressed[i] == false && i%4 == 1 && gameStatus == 2)
                    player.skok = 60
                controls.pressed[i] = true
            }
        }
        //console.log(controls.pressed)
    }
    window.onkeyup = function(event){
    //alert(event.keyCode)
        for(var i in controls.keycodes){
            if(event.keyCode == controls.keycodes[i])
                controls.pressed[i] = false
        }
        //console.log(controls.pressed)
    }
}
function movePlayer() {
    for(var i in controls.pressed){
        if(controls.pressed[i]){
            switch(i%4) {
                case 0:
                    if(player.pozycja > 0 && gameStatus == 2)
                        player.pozycja = player.pozycja - 2 
                    break;
                case 1:
                    break;
                case 2:
                    if(player.pozycja < 320 - player.dlugosc && gameStatus == 2)
                        player.pozycja = player.pozycja + 2
                    break;
                case 3:
                    if(gameStatus < 2){
                        gameStatus ++
                        prepareMenu(gameStatus)
                    }
                    console.log(gameStatus)
                    break;
            }
        }
    }
}